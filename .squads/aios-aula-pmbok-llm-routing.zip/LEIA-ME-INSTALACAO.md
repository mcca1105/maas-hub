# AIOS Expansion Pack — PMBOK Squad + LLM Routing Rule

> Material da aula do Cohort AIOS (13/Mar/2026)
> Instrutor: Sid Fernandes

---

## O que tem neste zip

| Item | Tipo | Caminho | Descricao |
|------|------|---------|-----------|
| **PMBOK Squad** | Expansion Pack | `squads/pmbok/` | 11 agentes de gerenciamento de projetos baseados no PMBOK 7th Edition |
| **LLM Routing Rule** | Claude Code Rule | `.claude/rules/llm-routing.md` | Regra de roteamento inteligente de modelos (Haiku/Sonnet/Opus) por agente e complexidade |

---

## Instalacao

### Pre-requisitos

- AIOS Core instalado (`npx aios-core doctor` deve passar)
- Claude Code funcionando no projeto

### Passo 1 — Extrair o zip

Extraia o conteudo deste zip **na raiz do seu projeto AIOS** (onde fica o `CLAUDE.md`).

A estrutura final deve ficar assim:

```
seu-projeto/
├── .claude/
│   └── rules/
│       └── llm-routing.md    ← NOVO (rule de roteamento)
├── squads/
│   └── pmbok/                ← NOVO (squad completo)
│       ├── squad.yaml
│       ├── README.md
│       ├── agents/           # 11 agentes
│       ├── tasks/            # 11 tasks
│       ├── workflows/        # 1 workflow (ciclo completo)
│       ├── checklists/       # 1 checklist
│       ├── config/           # Configuracoes
│       └── data/             # Referencia PMBOK 7
└── CLAUDE.md
```

### Passo 2 — Registrar a LLM Routing Rule no CLAUDE.md

Adicione esta secao no seu `CLAUDE.md` (no final ou na secao de regras):

```markdown
## LLM Model Routing

Ver `.claude/rules/llm-routing.md` para regras detalhadas.

**Resumo:**
- Haiku 4.5 para operacoes simples (leitura, config, git, templates)
- Sonnet 4.5 para desenvolvimento diario (implementacao, review, testes)
- Opus 4.6 para raciocinio complexo (arquitetura, debug profundo, design)
- Subagents do Task tool DEVEM especificar o parametro `model`
- Respeitar a tabela de roteamento por agente em llm-routing.md
```

> **Nota:** Rules dentro de `.claude/rules/` sao carregadas automaticamente pelo Claude Code em toda sessao. O trecho acima no CLAUDE.md serve apenas como referencia rapida.

### Passo 3 — Verificar instalacao

Abra uma nova sessao do Claude Code e teste:

```bash
# Verificar que o squad foi reconhecido
# (os comandos /pmbok:* devem aparecer)

# Testar ativacao do orquestrador
@pm-chief

# Ou gerar um plano completo
*plan
```

---

## Como usar o PMBOK Squad

### Modo rapido — Orquestrador

```
@pm-chief
*plan
```

O PM Chief (Atlas) coordena os 10 agentes e gera um plano de projeto completo seguindo o ciclo PMBOK:

```
Charter → Stakeholders → Escopo/WBS → Cronograma → Custos
→ Qualidade → Recursos → Comunicacao → Riscos → Aquisicoes
→ Plano Integrado
```

### Modo individual — Agente especifico

```
@scope-manager      # Ativar agente de escopo
*wbs                # Gerar WBS do projeto
```

### Tabela de agentes e comandos

| Agente | Persona | Area PMBOK | Comando |
|--------|---------|------------|---------|
| `@pm-chief` | Atlas | Orquestrador | `*plan` |
| `@integration-manager` | Iris | Integracao | `*charter` |
| `@scope-manager` | Sofia | Escopo | `*wbs` |
| `@schedule-manager` | Tempo | Cronograma | `*schedule` |
| `@cost-manager` | Dinero | Custos | `*budget` |
| `@quality-manager` | Quinn | Qualidade | `*quality-plan` |
| `@resource-manager` | Rex | Recursos | `*raci` |
| `@communications-manager` | Clara | Comunicacoes | `*comm-plan` |
| `@risk-manager` | Risco | Riscos | `*risk-register` |
| `@procurement-manager` | Petra | Aquisicoes | `*procurement-plan` |
| `@stakeholder-manager` | Stella | Partes Interessadas | `*stakeholder-register` |

---

## Como funciona o LLM Routing

A rule `.claude/rules/llm-routing.md` ensina o Claude Code a **escolher o modelo certo automaticamente** baseado em:

### 1. Tier do agente

| Tier | Modelo | Agentes | Custo |
|------|--------|---------|-------|
| TIER-1 (Economy) | Haiku 4.5 | @po, @sm, @ux, @devops | ~R$5/1M tokens |
| TIER-2 (Standard) | Sonnet 4.5 | @dev, @qa, @pm, @analyst | ~R$17/1M tokens |
| TIER-3 (Premium) | Opus 4.6 | @architect, @aios-master | ~R$29/1M tokens |

### 2. Complexidade da tarefa (override)

| Complexidade | Indicadores | Modelo |
|-------------|-----------|-------|
| SIMPLES | 1 arquivo, "fix", "typo", "rename" | Haiku |
| MEDIA | 2-5 arquivos, "implement", "create" | Sonnet |
| COMPLEXA | 6+ arquivos, "architect", "security" | Opus |

### 3. Na pratica

O Claude Code vai:
- **Sugerir** troca de modelo quando detectar mismatch (ex: rodando Opus para tarefa simples)
- **Nunca trocar automaticamente** — apenas sugere
- **Respeitar sua escolha** se voce definir manualmente

---

## Duvidas

- Releia o `squads/pmbok/README.md` para detalhes do squad
- Releia o `.claude/rules/llm-routing.md` para a rule completa
- Pergunte ao seu AIOS: ele sabe interpretar ambos os arquivos
